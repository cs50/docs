from flask import Flask, redirect, render_template, request, url_for
import csv

# configure application
app = Flask(__name__)


@app.route("/")
def index():
    """
    Routes to website's index.
    """
    return render_template("index.html")

@app.route("/submit", methods=["GET", "POST"])
def submit():
    """
    Records complete form data (via POST) to `contacts.csv`. If form is incomplete, renders `whoops.html`.
    """

    # TODO
