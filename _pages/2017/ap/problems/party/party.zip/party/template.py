#http://pyfpdf.readthedocs.io/en/latest/reference/cell/index.html

from fpdf import FPDF
import datetime

now = datetime.datetime.now()

class PDF(FPDF):
    def header(self):
        # Logo (image name, horizontal offset, vertical offset, height of image while maintaining ratio)
        self.image('muppet.jpg', 10, 10, 60)
        # Line break (height of header)
        self.ln(40)
        
    def print_address(self, first_name, last_name, address, city, state, zipcode):
        # Arial 12
        self.set_font('Times', '', 12)
        # Title (w,h=0,txt='',border=0,ln=0, align='', fill=0,)
        self.cell (0, 5, '%s %s' % (first_name, last_name), 0, 1, 'L', 0)
        # Title (w,h=0,txt='',border=0,ln=0,align='',fill=0)
        self.cell (0, 5, '%s' % (address), 0, 1, 'L', 0)
        # Title (w,h=0,txt='',border=0,ln=0,align='',fill=0,)
        self.cell (0, 5, '%s, %s %s' % (city, state, zipcode), 0, 1, 'L', 0)
        # Line break
        self.ln(8)
        
    def greeting(self, name):   
         self.cell (0, 5, 'Dear %s,' % (name), 0, 1, 'L', 0)
         self.cell (0, 5, '\n', 0, 1, 'L', 0)
  
        
    def format_body(self):   
        body = open('body.txt')
        text = body.read()
        a = text.split('\n\n')
        for text in a:
            self.cell (0, 5, '%s' % (text), 0, 1, 'L', 0)
            self.cell (0, 5, '\n', 0, 1, 'L', 0)
    
    def signature(self, sender):   
        self.cell (0, 40, 'Sincerely,', 0, 1, 'R', 0)
        self.cell (0, 5, '%s' % (sender), 0, 1, 'R', 0)
        

# Instantiation of inherited class
pdf = PDF()
pdf.add_page()
# font, style (B for bold, I for Italic, etc), font size
pdf.set_font('Times', '', 12)
pdf.print_address('David J.', 'Malan', '33 Oxford Street', 'Cambridge', 'MA', '02138')
# print date in month, day year format
pdf.cell (0, 5, '%s' % now.strftime("%B %d, %Y"), 0, 1, 'R', 0)
pdf.greeting('David J.')
pdf.format_body()
pdf.signature('Sender')
pdf.output('template.pdf', 'F')