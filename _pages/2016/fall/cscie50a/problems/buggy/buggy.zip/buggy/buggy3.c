/**
 * Should calculate the hypotenuse of a right triangle using the pythagorean formula
 */
 
#include <stdio.h>
#include <cs50.h>
#include <math.h>
 
 // prototype
double pythag(double a);

int main(void)
{
    printf("Give me a leg of a triangle:");
    double x = get_double();
    printf("Give me the other leg:");
    double y = get_double();
    
    double hypotenuse_squared = pow(x, 2) + pow(y, 2);
    pythag(hypotenuse_squared);
    printf("The hypotenuse is %f \n", hypotenuse_squared);
}
 
// function definition
double pythag(double a)
{
    double hypotenuse = sqrt(a);
    return hypotenuse;
}