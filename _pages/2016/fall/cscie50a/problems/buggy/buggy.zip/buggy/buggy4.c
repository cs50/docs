/**
 * Should print the longest phone call a user can make given that the user
 * has s cents and the first minute of a talk costs min1 cents, each minute from the 2nd up 
 * to the 10th (inclusive) costs min2_10 cents each minute after 10th costs min11 cents
 **/
 
 #include <stdio.h>
 #include <cs50.h>

// prototype
int phoneCall(int min1, int min2_10, int min11, int s);

int main(void)
{
    printf("The first minute costs: ");
    int num1 = get_int();
    printf("The minutes 2-10 cost: ");
    int num2 = get_int();
    printf("Any minute after the 10th costs: ");
    int num3 = get_int();
    printf("The total amount of change I have is: ");
    int num4 = get_int();
    int n = phoneCall(num1, num2, num3, num4);
    printf("The longest phone call that can be made is %i minutes long.\n", n);
}

int phoneCall(int min1, int min2_10, int min11, int s)
{
    int call = 0;

    while (min1 < s)
    {
        call = 1;
        break;
    }
    for (int i = 0; i < 10; i++)
    {
        while ((min1 + min2_10 * (call)) < s)   
        {  
            call += 1;
            break;
        }
    }
    while ((min1 + (9 * min2_10) + (min11 * (call - 9))) < s)
    {
        call += 1;
    }
    return(call);
}