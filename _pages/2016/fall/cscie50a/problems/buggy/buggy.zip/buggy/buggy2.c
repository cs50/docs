/**
 * Should print name character by character or exit 
 * the program if passed in anything but alphabetic characters
 **/
 
#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    printf("name:");
    string n = get_string();

        if(!isalpha('n'))
        {
            printf("invalid \n");
            return 1;
        }

        for(int i = 0; i < strlen(n); i++)
        {
            printf("%c\n", n[i]);
        }
        return 0;
    
    
    
}