<?php
    // useful globals
    $font_size = 12;
    $font_name = "Times";

    require_once("helpers.php");

    // create the PDF
    $pdf = create_pdf();

    // write a fun image at the top left corner, two inches wide
    insert_image($pdf, "muppet.jpg", 2.0);
    
    // write the address line
    write_address($pdf, "First Last", "Address", "City, State ZIP");
  
    // write today's date (after formatting it as a string with date())
    write_date($pdf, date("F j, Y"));
    
    // write the message body
    write_greeting($pdf, "First");
    
    // write the body of the message
    write_body($pdf, "body.txt");
  
    // write the signature area
    write_signature($pdf, "Sincerely,", "Sender");
    
    // save the file
    save_as($pdf, "output/template.pdf");

?>