<?php
    
    print("One share of $name [$symbol] costs $$price.\n");
    print("You can afford $num shares of $name.\n");
    
?>