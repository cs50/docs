#define TITLE "Blockdude50"
#define AUTHOR "Sally Student"

#define DISPLACE 2
#define WIDTH 60
#define DATALENGTH 100
#define LASTLVL 5

#define SPACE ' '
#define BRICK '='
#define BLOCK '#'
#define PLAYER 'O'
#define PRIGHT '>'
#define PLEFT '<'
#define EXIT '*'
#define BORDERLR '|'
#define BORDERTB '-'
#define BCORNER '+'

#define CODE2 29285
#define CODE3 4912
#define CODE4 38512
#define CODE5 50

#define L1 "lvl1.txt"
#define L2 "lvl2.txt"
#define L3 "lvl3.txt"
#define L4 "lvl4.txt"
#define L5 "lvl5.txt"