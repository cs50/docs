/****************************************************************************
 * sudoku.h
 *
 * CS50 AP
 * Sudoku (Part 2)
 *
 * Compile-time options for the game of Sudoku.
 * Function prototypes and other information factored out of sudoku.c
 * 
 ***************************************************************************/

// game's author
#define AUTHOR "Sally Student"

// game's title
#define TITLE "Sudoku"

// banner's colors
#define FG_BANNER COLOR_RED
#define BG_BANNER COLOR_BLACK

// grid's colors
#define FG_GRID COLOR_RED
#define BG_GRID COLOR_BLACK

// border's colors
#define FG_BORDER COLOR_WHITE
#define BG_BORDER COLOR_RED

// logo's colors
#define FG_LOGO COLOR_WHITE
#define BG_LOGO COLOR_BLACK

// digits's colors
#define FG_DIGITS COLOR_YELLOW
#define BG_DIGITS COLOR_BLACK

// nicknames for pairs of colors
enum { PAIR_BANNER = 1, PAIR_GRID, PAIR_BORDER, PAIR_LOGO, PAIR_DIGITS };

// function prototypes and includes
#include <ctype.h>
#include <ncurses.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


// macro for processing control characters
#define CTRL(x) ((x) & ~0140)

// size of each int (in bytes) in *.bin files
#define INTSIZE 4


// wrapper for our game's globals
struct
{
    // the current level
    char *level;

    // the game's board
    int board[9][9];

    // the board's number
    int number;

    // the board's top-left coordinates
    int top, left;

    // the cursor's current location between (0,0) and (8,8)
    int y, x;
} g;


// prototypes
void draw_grid(void);
void draw_borders(void);
void draw_logo(void);
void draw_numbers(void);
void hide_banner(void);
bool load_board(void);
void handle_signal(int signum);
void log_move(int ch);
void redraw_all(void);
bool restart_game(void);
void show_banner(char *b);
void show_cursor(void);
void shutdown(void);
bool startup(void);

// added prototypes from Problem 4-0
void move_cursor(int ch);
void update_numbers(int ch);
