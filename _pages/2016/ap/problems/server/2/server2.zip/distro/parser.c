/**
 * parser.c
 *
 * Computer Science 50
 * Problem 6-6
 *
 * Implements a parser for a server.
 */


#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "parser.h"

char* extract_request(char* message)
{
    // extract message's request-line
    // http://www.w3.org/Protocols/rfc2616/rfc2616-sec5.html
    const char* haystack = message;
    const char* needle = strstr(haystack, "\r\n");
    if (needle == NULL)
    {
        error(500);
        return NULL;
    }
    char* line = malloc(needle - haystack + 2 + 1);
    strncpy(line, haystack, needle - haystack + 2);
    line[needle - haystack + 2] = '\0';
    
    return line;
}

void extract_headers(char* content, size_t length)
{
    // subtract php-cgi's headers from content's length to get body's length
    char* haystack = content;
    char* needle = strstr(haystack, "\r\n\r\n");
    if (needle == NULL)
    {
        free(content);
        error(500);
        return;
    }

    // extract headers
    char headers[needle + 2 - haystack + 1];
    strncpy(headers, content, needle + 2 - haystack);
    headers[needle + 2 - haystack] = '\0';

    // respond with interpreter's content
    respond(200, headers, needle + 4, length - (needle - haystack + 4));
}

void extract_query(char target[], char* abs_path, char* query)
{
    // find end of absolute-path in request-target
    const char* haystack = target;
    const char* needle = strchr(haystack, '?');
    if (needle == NULL)
    {
        needle = target + strlen(target);
    }

    // extract absolute-path 
    strncpy(abs_path, target, needle - haystack);
    abs_path[needle - haystack] = '\0';

    // find start of query in request-target
    if (*needle == '?')
    {
        needle = needle + 1;
    }

    // extract query
    strcpy(query, needle);
}

bool parse(const char* line, char* abs_path, char* query)
{
    // ensure arguments aren't NULL
    if (line == NULL || abs_path == NULL || query == NULL)
    {
        return false;
    }

    // find first SP in request-line
    const char* haystack = line;
    const char* needle = strchr(haystack, ' ');
    if (needle == NULL)
    {
        error(400);
        return false;
    }

    // extract method
    char method[needle - haystack + 1];
    strncpy(method, haystack, needle - haystack);
    method[needle - haystack] = '\0';

    // find second SP in request-line
    haystack = needle + 1;
    needle = strchr(haystack, ' ');
    if (needle == NULL)
    {
        error(400);
        return false;
    }

    // extract request-target
    char target[needle - haystack + 1];
    strncpy(target, haystack, needle - haystack);
    target[needle - haystack] = '\0';

    // find first CRLF in request-line
    haystack = needle + 1;
    needle = strstr(haystack, "\r\n");
    if (needle == NULL)
    {
        error(414);
        return false;
    }

    // extract HTTP-version
    char version[needle - haystack + 1];
    strncpy(version, haystack, needle - haystack);
    version[needle - haystack] = '\0';

    // ensure request's method is GET
    if (strcmp("GET", method) != 0)
    {
        error(405);
        return false;
    }

    // ensure request-target starts with absolute-path
    if (target[0] != '/')
    {
        error(501);
        return false;
    }

    // ensure request-target is safe
    // http://www.rfc-editor.org/rfc/rfc3986.txt
    if (strchr(target, '"') != NULL)
    {
        error(400);
        return false;
    }

    // ensure HTTP-version is HTTP/1.1
    if (strcmp("HTTP/1.1", version) != 0)
    {
        error(505);
        return false;
    }

    extract_query(target, abs_path, query);

    // parsed
    return true;
}