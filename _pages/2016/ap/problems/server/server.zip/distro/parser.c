/**
 * parser.c
 *
 * Computer Science 50
 * Problem 6-6
 *
 * Implements a parser for a server.
 */


#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "parser.h"

char* extract_request(char* message)
{
    // TODO
    return NULL;
}

void extract_headers(char* content, size_t length)
{
    // TODO
}

void extract_query(char target[], char* abs_path, char* query)
{
    // TODO
}

bool parse(const char* line, char* abs_path, char* query)
{
    // TODO
    return false;
}