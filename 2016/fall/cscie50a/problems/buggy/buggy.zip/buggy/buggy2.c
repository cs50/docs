/**
 * Should print name character by character or exit 
 * the program if passed in anything but alphabetic characters
 **/
 
#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    printf("name:");
    string n = get_string();
    
    // check to see if name is all letters
    for (int i = 0; i < strlen(n); i++)
    {
        if(!isalpha(n[i]))
        {
            printf("invalid \n");
            return 1;
        }
    }
    
    // print name string letter by letter
        for(int j = 0; j < strlen(n); j++)
        {
            printf("%c\n", n[j]);
        }
        return 0;
    
    
    
}