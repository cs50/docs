/**
 * Given that there are n children and m pieces of candy. This program
 * should print the maximum number of candies the children could have ate 
 * given that they all have to eat the same amount and candies can't be split
 **/
 
 #include <stdio.h>
 #include <cs50.h>

int main(void)
{
    printf("number of children: ");
    int n = get_int();
    printf("pieces of candy: ");
    int m = get_int();
    
    int counter = 0;
    while (m > n)
    {
        if (m - n > 0)
        {
            counter += 1;
            m -= n;
        }
    }
    
    printf("The children ate %i pieces of candy\n", counter);
}