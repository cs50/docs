/************************************
 * autocomplete.h
 * 
 * CS50 AP
 * Problem 5-3
 ************************************/

// prototypes - do not modify

/**
 * Searches through the trie for all words beginning with the parameter string
 * and prints them out. Then frees the previously-loaded trie. Returns 0 on 
 * success, returns -1 on any failure
 */
int autocomplete(const char* expr);

/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void);

// additional prototypes, if any
// TODO