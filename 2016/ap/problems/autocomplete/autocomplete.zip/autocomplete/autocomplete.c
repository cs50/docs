/************************************
 * autocomplete.c
 * 
 * CS50 AP
 * Problem 5-3
 ************************************/
 
// includes
#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "trie.h"
#include "autocomplete.h"

/**
 * Searches through the trie for all words beginning with the parameter string
 * and prints them out. Then frees the previously-loaded trie. Returns 0 on 
 * success, returns -1 on any failure
 */
int autocomplete(const char* expr)
{
    // TODO
    return -1;
}


/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void)
{
    // TODO
    return false;
}