/****************************************
 * trie.c
 * 
 * CS50 AP
 * Problem 5-3
 * 
 * Jack Deschler
 * Doug Lloyd
 ****************************************/

// includes
#include <ctype.h>
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "trie.h"
#include "autocomplete.h"

// main driver for the autocomplete program
int main(int argc, char* argv[])
{
    // check for correct number of args
    if (argc != 3 && argc != 2)
    {
        printf("Usage: %s [dictionary] expr\n", argv[0]);
        return 1;
    }
    
    // save the dictionary and first letters of the string to be searched
    char* dictionary = (argc == 3) ? argv[1] : DICTIONARY;
    char* expr = (argc == 3) ? argv[2] : argv[1];
    
    // attempt to load the dictionary into the trie
    bool loaded = load(dictionary);
    if (!loaded)
    {
        printf("Could not load %s.\n", dictionary);
        return 2;
    }
    
    return autocomplete(expr);
}
/**
 * Loads dictionary into memory. Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    // allocate and initialize root of trie
    trie = malloc(sizeof(node));
    if (trie == NULL)
    {
        return false;
    }
    
    trie->word = NULL;
    for (int i = 0; i < CHILDREN; i++)
    {
        trie->children[i] = NULL;
    }

    // open dictionary file
    FILE* file = fopen(dictionary, "r");
    if (file == NULL)
    {
        return false;
    }

    // buffer to hold the word obtained from the dictionary file
    char word[LENGTH + 1];

    // iterate over words in dictionary, reading them one at a time
    while (fscanf(file, "%s", word) != EOF)
    {
        // insert word into trie
        node* current = trie;
        for (int i = 0, n = strlen(word); i < n; i++)
        {
            // map character to array index
            int index = map(word[i]);

            // index into trie
            // if the current path down the trie doesn't exist, construct it
            if (current->children[index] == NULL)
            {
                // allocate space for the newly-created node
                node* newnode = malloc(sizeof(node));
                if (newnode == NULL)
                {
                    unload();
                    return false;
                }
                
                // initialize the newly created node (by default, empty)
                newnode->word = NULL;
                for (int i = 0; i < CHILDREN; i ++)
                    newnode->children[i] = NULL;

                // insert node into trie
                current->children[index] = newnode;
            }
            
            // move down one level in the trie
            current = current->children[index];
        }

        // insert the word into the trie
        current->word = malloc(sizeof(char)*(strlen(word) + 1));
        strcpy(current->word, word);
    }

    // close file
    fclose(file);

    // success
    return true;
}

/**
 * maps a character to its correct index in children array 
 */
int map(char c)
{
    return (isalpha(c)) ? (tolower(c) - 'a') : CHILDREN-1;
}