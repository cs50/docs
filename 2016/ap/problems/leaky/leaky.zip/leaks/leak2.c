/*******************************
 * leak2.c
 * 
 * CS50 AP
 * Problem 5-2
 *******************************/

// defines
#define _XOPEN_SOURCE
#define NUMS 50

// includes
#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
#include <time.h>

// prototypes
void bar(void);
void foo(void);
void baz(void);

// global declarations
int* ptrs[NUMS];

int main(int argc, char* argv[])
{
    baz();
    for (int i = 0; i < NUMS; i++)
    {
        ptrs[i] = malloc(sizeof(int));
    }
    bar();
    foo();
}

void bar(void)
{
    srand48(time(NULL));
    for (int i = 0; i < NUMS; i ++)
        *(ptrs[i]) = drand48() * 100;
}

void foo(void)
{
    for (int i = 0; i < NUMS; i ++)
    {
        printf("%d\n", *(ptrs[i]));
    }    
}

void baz(void)
{
    for (int i = 0; i < NUMS; i++)
    {
        printf("%p\n", ptrs[i]);
    }    
}
