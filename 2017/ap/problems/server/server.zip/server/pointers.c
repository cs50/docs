#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char* argv[])
{
    // sentence to use
    char *sentence = "hello, world";

    // find the "," in the sentence
    char *comma = strchr(sentence, ',');

    // find the length of the first word
    int length1 = comma - sentence;

    // store first word in separate variable
    char first_word[length1 + 1];
    strncpy(first_word, sentence, length1);
    first_word[length1] = '\0';

    // find and store second word
    char *world = strstr(sentence, "world");
    int length2 = strlen(world);
    char *second_word = malloc(length2 + 1);
    strcpy(second_word, world);

    printf("The sentence is \"%s\". The first word is \"%s\" and second word is \"%s\"\n",
            sentence, first_word, second_word);
    free(second_word);
}
