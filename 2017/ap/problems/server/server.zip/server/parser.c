/**
 * parser.c
 *
 * CS50 AP
 * Server
 *
 * Implements a parser for a server.
 */

#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "parser.h"

char *extract_request(char *message)
{
    // TODO
}

void extract_headers(char *content, size_t length)
{
    // TODO
}

void extract_query(char target[], char * abs_path, char * query)
{
    // TODO
}

bool parse(const char *line, char *abs_path, char *query)
{
    // TODO
}
