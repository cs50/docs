/**
 * parser.h
 *
 * CS50 AP
 * Server
 *
 * Implements a parser for a server.
 */


#ifndef PARSER_H
#define PARSER_H

#include <stdbool.h>
#include <math.h>

/**
 * Responds to client with specified status code.
 */
void error(unsigned short code);

/**
 * Extracts a HTTP message's request-line
 */
char* extract_request(char* message);

/**
 * Extracts a HTTP message's headers
 */
void extract_headers(char* content, size_t length);

/**
 * Parses a request-target, storing its absolute-path at abs_path
 * and its query string at query, both of which are assumed
 * to be at least of length LimitRequestLine + 1.
 */
void extract_query(char target[], char* abs_path, char* query);

/**
 * Parses a request-line, ensuring a correctly formatted request-line
 */
bool parse(const char* line, char* path, char* query);

/**
 * Responds to a client with status code, headers, and body of specified length.
 */
void respond(int code, const char* headers, const char* body, size_t length);

#endif // PARSER_H
