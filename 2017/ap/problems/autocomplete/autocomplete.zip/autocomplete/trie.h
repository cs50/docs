/**
 * trie.h
 *
 * CS50 AP
 * Autocomplete
 *
 * Implements autocomplete functionality with a trie.
 */

// ensure the file is not included twice
#ifndef TRIE_H
#define TRIE_H

// defined constants
#define CHILDREN 27 // one per letter, and one for apostrophe
#define APOSTROPHE 39 // ASCII value of apostrophe
#define LENGTH 45 // maximum length of a dictionary word
#define DICTIONARY "large.txt" // default dictionary if none provided

// struct definition for nodes in trie
typedef struct node
{
    char *word;
    struct node *children[CHILDREN];
}
node;

// pointer for the root of our trie
node *trie;

// function prototypes
bool load(const char *dictionary);
int map(char c);
bool unload(void);

#endif
