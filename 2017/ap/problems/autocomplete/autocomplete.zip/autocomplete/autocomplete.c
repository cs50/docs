/**
 * autocomplete.c
 *
 * CS50 AP
 * Autocomplete
 *
 * Implements autocomplete functionality with a trie.
 */

#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "autocomplete.h"
#include "trie.h"

/**
 * Searches through the trie for all words beginning with the parameter string
 * and prints them out. Then frees the previously-loaded trie. Returns 0 on
 * success, returns -1 on any failure.
 */
int autocomplete(const char *expr)
{
    // TODO
    return -1;
}


/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void)
{
    // TODO
    return false;
}
